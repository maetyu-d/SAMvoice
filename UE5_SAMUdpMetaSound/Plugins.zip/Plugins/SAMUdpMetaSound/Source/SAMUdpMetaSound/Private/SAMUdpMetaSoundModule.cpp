#include "SAMUdpMetaSoundModule.h"

void FSAMUdpMetaSoundModule::StartupModule()
{
}

void FSAMUdpMetaSoundModule::ShutdownModule()
{
}

IMPLEMENT_MODULE(FSAMUdpMetaSoundModule, SAMUdpMetaSound)
